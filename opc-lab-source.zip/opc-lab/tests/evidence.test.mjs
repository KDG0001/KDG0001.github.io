import test from 'node:test';
import assert from 'node:assert/strict';
import {DEFAULTS,CELLS,makeScene,initialMask,compare,gaussian} from '../dist/model.js';
import {NOTE_FIELDS,cleanFields,describeConditions,physicsStamp,experimentData,DEFAULT_DEVELOPMENT} from '../dist/evidence.js';
test('exported model support and domain reflect actual discretization',()=>{
  for(const grid of [3.5,1.75,.875])for(const id of Object.keys(CELLS)){
    const cfg={...DEFAULTS,grid},scene=makeScene(id,cfg),d=describeConditions(scene,cfg),kernel=gaussian(cfg);
    assert.equal(d.domain.xMinNm,-42);assert.equal(d.domain.xMaxNm,CELLS[id].width+42);
    assert.equal(d.domain.nx,scene.nx);assert.equal(d.domain.widthNm,scene.width);
    assert.equal(d.gaussian.sidePixels,kernel.weights.length);
    assert.equal(d.gaussian.halfWidthNm,kernel.radius*grid);
    assert.equal(d.gaussian.centerWeight,kernel.weights[kernel.radius]**2);
    assert.ok(Math.abs(d.gaussian.sum2D-1)<1e-12);
  }
});
test('experiment export keeps binary before/after masks, analysis provenance and AI notes across JSON serialization',()=>{
  const sessions={};for(const id of Object.keys(CELLS)){
    const scene=makeScene(id,DEFAULTS),mask=initialMask(scene,DEFAULTS);
    sessions[id]={scene,mask,comparison:compare(scene,DEFAULTS,mask),kind:'초기',history:[],actions:[],notes:{lineEnds:'상단 끝 위치를 비교함'},noteConditions:physicsStamp(DEFAULTS)};
  }
  const data=JSON.parse(JSON.stringify(experimentData(DEFAULTS,'INV_X1',sessions,DEFAULT_DEVELOPMENT)));
  for(const [id,s] of Object.entries(data.sessions)){
    assert.deepEqual(s.mask,s.baselineMask);assert.equal(s.before.dose.length,s.nx*s.ny);
    assert.equal(s.after.printed.length,s.nx*s.ny);assert.equal(s.notes.lineEnds,'상단 끝 위치를 비교함');
    assert.equal(s.notesMatchCurrentConditions,true);assert.equal(s.conditions.tone,'negative');
  }
  assert.match(data.development.requirements,/요청/);
  sessions.INV_X1.noteConditions=physicsStamp({...DEFAULTS,threshold:.6});
  assert.equal(experimentData(DEFAULTS,'INV_X1',sessions,DEFAULT_DEVELOPMENT).sessions.INV_X1.notesMatchCurrentConditions,false);
  assert.notEqual(physicsStamp(DEFAULTS),physicsStamp({...DEFAULTS,sigma:4.3}));
  assert.equal(cleanFields({linewidth:42},NOTE_FIELDS).linewidth,'');
});
