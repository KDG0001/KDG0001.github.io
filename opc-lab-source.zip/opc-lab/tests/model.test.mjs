import test from 'node:test';
import assert from 'node:assert/strict';
import {CELLS,DEFAULTS,makeScene,initialMask,gaussian,expose,develop,evaluate,optimize,metrics,validateConfig} from '../dist/model.js';
test('provided Metal1 geometry has correct bounds and exact area across grid choices',()=>{
  for(const grid of [3.5,1.75,.875]){
    for(const [id,expectedArea] of [['INV_X1',3307.5],['NAND2_X4',9922.5]]){
      const cfg={...DEFAULTS,grid},scene=makeScene(id,cfg);
      assert.equal(scene.width,CELLS[id].width+84);assert.equal(scene.height,273);
      assert.equal(scene.target.reduce((a,b)=>a+b,0)*grid*grid,expectedArea);
      const x=(nm)=>Math.round((nm+42)/grid),y=(nm)=>Math.round((nm+42)/grid);
      assert.equal(scene.target[y(0)*scene.nx+x(0)],1);
      assert.equal(scene.target[0],0);
    }
  }
});
test('Gaussian uses unit discrete sum, symmetry, and correct dose for uniform transmission',()=>{
  const k=gaussian(DEFAULTS);assert.ok(Math.abs(k.weights.reduce((a,b)=>a+b,0)-1)<1e-12);
  for(let i=0;i<k.weights.length;i++)assert.equal(k.weights[i],k.weights.at(-1-i));
  const s=makeScene('INV_X1',DEFAULTS),m=new Uint8Array(s.target.length).fill(1),cfg={...DEFAULTS,tone:'positive',dose:1.2};
  for(const v of expose(s,cfg,m))assert.ok(Math.abs(v-1.2)<1e-12);
});
test('positive complement gives complementary exposure and equivalent retained PR at dose 1 and threshold .5',()=>{
  const scene=makeScene('NAND2_X4',DEFAULTS),neg=expose(scene,DEFAULTS,initialMask(scene,DEFAULTS));
  const posCfg={...DEFAULTS,tone:'positive'},pos=expose(scene,posCfg,initialMask(scene,posCfg));
  for(let i=0;i<neg.length;i++)assert.ok(Math.abs(neg[i]+pos[i]-1)<1e-12);
  assert.deepEqual(develop(neg,DEFAULTS),develop(pos,posCfg));
});
test('metrics distinguish missing and excess area and use actual pixel area',()=>{
  const m=metrics(Uint8Array.from([1,1,0,0]),Uint8Array.from([1,0,1,0]),2);
  assert.equal(m.iou,1/3);assert.equal(m.mismatchArea,8);assert.equal(m.missingArea,4);assert.equal(m.excessArea,4);
});
test('automatic correction improves both cells and never accepts worse hard mismatch',async()=>{
  for(const id of Object.keys(CELLS)){
    const scene=makeScene(id,DEFAULTS),mask=initialMask(scene,DEFAULTS),before=evaluate(scene,DEFAULTS,mask);
    const out=await optimize(scene,DEFAULTS,mask);
    assert.ok(out.result.metrics.mismatchArea<before.metrics.mismatchArea);
    assert.ok(out.result.metrics.iou>before.metrics.iou);
    for(let i=1;i<out.history.length;i++)assert.ok(out.history[i].mismatchPixels<=out.history[i-1].mismatchPixels);
    assert.deepEqual(mask,initialMask(scene,DEFAULTS),'input mask is preserved');
    const repeated=await optimize(scene,DEFAULTS,mask);assert.deepEqual(repeated.mask,out.mask,'optimization is deterministic');
  }
});
test('invalid configs are rejected and discretization is explicitly bounded',()=>{
  assert.throws(()=>validateConfig({grid:.1}));assert.throws(()=>validateConfig({threshold:NaN}));assert.throws(()=>validateConfig({sigma:0}));
  assert.equal(validateConfig({padding:0}).padding,42);
});
