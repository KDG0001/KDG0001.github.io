"""Package a runnable, credential-free source download for the static app."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path(__file__).resolve().parent.parent
destination = root / 'dist' / 'opc-lab-source.zip'
sources = [root / 'package.json', root / 'README.md', root / 'DEVELOPMENT.md']
sources += sorted((root / 'dist').glob('*.js'))
sources += sorted((root / 'dist').glob('*.html'))
sources += sorted((root / 'dist').glob('*.css'))
sources += sorted((root / 'dist').glob('*.webmanifest'))
sources += sorted((root / 'dist').glob('*.pdf'))
sources += sorted((root / 'dist').glob('*verification*.json'))
sources += sorted((root / 'docs').glob('*.md'))
sources += sorted((root / 'dist' / 'icons').glob('*.png'))
sources += sorted((root / 'tests').glob('*.mjs'))
sources += [Path(__file__).resolve()]
sources += [root / 'scripts' / 'build-standalone.py']
with ZipFile(destination, 'w', ZIP_DEFLATED) as archive:
    for source in sources:
        archive.write(source, Path('opc-lab') / source.relative_to(root))
print(f'Source download ready: {destination.name} ({destination.stat().st_size} bytes)')
