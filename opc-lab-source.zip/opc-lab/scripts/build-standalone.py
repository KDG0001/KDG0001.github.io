"""Build a single-file offline OPC app from the tested static source."""
from pathlib import Path
from base64 import b64encode
import argparse
import json
import re

parser=argparse.ArgumentParser()
parser.add_argument('output')
args=parser.parse_args()
root=Path(__file__).resolve().parent.parent
dist=root/'dist'
html=(dist/'index.html').read_text()
model=re.sub(r'^export ', '', (dist/'model.js').read_text(), flags=re.M)
evidence=re.sub(r'^import .*?;\n', '', (dist/'evidence.js').read_text(), flags=re.M)
evidence=re.sub(r'^export ', '', evidence, flags=re.M)
app=re.sub(r'^import .*?;\n', '', (dist/'app.js').read_text(), flags=re.M)
worker=re.sub(r'^import .*?;\n', '', (dist/'worker.js').read_text(), flags=re.M)
app=app.replace("new Worker(new URL('./worker.js',import.meta.url),{type:'module'})",'new Worker(URL.createObjectURL(new Blob(['+json.dumps(model+'\n'+worker,ensure_ascii=False)+'],{type:"text/javascript"})))')
html=html.replace('<link rel="stylesheet" href="./styles.css"><script type="module" src="./app.js"></script><script type="module" src="./install.js"></script>','<style>'+(dist/'styles.css').read_text()+'</style>')
html=re.sub(r'<link rel="manifest"[^>]*>','',html)
html=re.sub(r'<button class="button subtle" id="install-open">.*?</button>','',html)
html=re.sub(r'<dialog id="install-dialog".*?</dialog>','',html,flags=re.S)
html=html.replace('href="./" aria-label="OPC Lab 시작"','href="#" aria-label="OPC Lab 시작"')
assets={'./icons/apple-touch-180.png':('image/png',dist/'icons/apple-touch-180.png'),'./opc-lab-source.zip':('application/zip',dist/'opc-lab-source.zip'),'./02_OPC_User_Manual.pdf':('application/pdf',dist/'02_OPC_User_Manual.pdf'),'./OPC_Assignment_Checklist.pdf':('application/pdf',dist/'OPC_Assignment_Checklist.pdf')}
for uri,(mime,path) in assets.items():
    html=html.replace(uri,'data:'+mime+';base64,'+b64encode(path.read_bytes()).decode())
script=model+'\n'+evidence+'\n'+app
if '</script' in script.lower():raise ValueError('Unexpected closing script sequence')
html=html.replace('</body>', '<script type="module">\n'+script+'\n</script></body>')
out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(html)
print(f'{out}: {out.stat().st_size} bytes')
